export const defaultImagePath =
  'https://media.istockphoto.com/id/1159947597/vector/add-photos-concept-line-icon-simple-element-illustration.jpg?s=612x612&w=0&k=20&c=eU2aJxlWFKDle1-NS8KBOzRYrEgSSJ4QVKorAmp467M=';
