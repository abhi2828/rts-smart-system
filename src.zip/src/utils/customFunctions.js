export function convertToUpperCase(str) {
    return str.toUpperCase();
  }
  